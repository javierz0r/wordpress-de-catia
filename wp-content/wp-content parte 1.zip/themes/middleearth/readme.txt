Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/middleearth/
Buy theme: http://smthemes.com/buy/middleearth/
Support Forums: http://smthemes.com/support/forum/middleearth-free-wordpress-theme/